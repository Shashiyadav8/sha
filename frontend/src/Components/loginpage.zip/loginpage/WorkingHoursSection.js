import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './WorkingHoursSection.css';

const WorkingHoursSection = () => {
  const [month, setMonth] = useState('');
  const [summary, setSummary] = useState([]);
  const [totalHours, setTotalHours] = useState(0);
  const token = localStorage.getItem('token');

 useEffect(() => {
  const fetchSummary = async () => {
    if (!month) return;
    try {
      const res = await axios.get(`http://localhost:5000/api/attendance/summary?month=${month}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setSummary(res.data.summary);
      setTotalHours(res.data.totalHours);
    } catch (err) {
      console.error('Failed to fetch summary:', err);
    }
  };

  fetchSummary();
}, [month, token]); // ✅ Dependency array

  return (
    <div className="working-hours-section">
      <h3>Working Hours Summary</h3>

      <label>Select Month:</label>
      <input
        type="month"
        value={month}
        onChange={(e) => setMonth(e.target.value)}
      />

      {summary.length > 0 ? (
  <>
    {/* Desktop Table */}
    <table className="desktop-only">
      <thead>
        <tr>
          <th>Date</th>
          <th>Punch In</th>
          <th>Punch Out</th>
          <th>Hours</th>
        </tr>
      </thead>
      <tbody>
        {summary.map((record, idx) => (
          <tr key={idx}>
            <td>{record.date}</td>
            <td>{record.punch_in_time ? new Date(record.punch_in_time).toLocaleTimeString() : '-'}</td>
            <td>{record.punch_out_time ? new Date(record.punch_out_time).toLocaleTimeString() : '-'}</td>
            <td>{record.hours}</td>
          </tr>
        ))}
      </tbody>
    </table>

    {/* Mobile Cards */}
    <div className="mobile-only">
      {summary.map((record, idx) => (
        <div className="working-hours-card" key={idx}>
          <p><strong>Date:</strong> {record.date}</p>
          <p><strong>Punch In:</strong> {record.punch_in_time ? new Date(record.punch_in_time).toLocaleTimeString() : '-'}</p>
          <p><strong>Punch Out:</strong> {record.punch_out_time ? new Date(record.punch_out_time).toLocaleTimeString() : '-'}</p>
         <p><strong>Total Hours:</strong> {totalHours.toFixed(2)} hrs</p>

        </div>
      ))}
    </div>
  </>
) : (
  <p>No data for selected month.</p>
)}

    </div>
  );
};

export default WorkingHoursSection;
