import React, { useEffect, useState, useCallback } from 'react';
import axios from 'axios';
import './LeaveSection.css';

const LeaveSection = () => {
  const token = localStorage.getItem('token');
  const [leaves, setLeaves] = useState([]);
  const [form, setForm] = useState({ start_date: '', end_date: '', reason: '' });
  const [filterMonth, setFilterMonth] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  // ✅ Fetch leaves
  const fetchLeaves = useCallback(async () => {
  try {
    const res = await axios.get('http://localhost:5000/api/leaves', {
      headers: { Authorization: `Bearer ${token}` },
    });
    console.log('Fetched leaves:', res.data); // 🔍 See if any duplicates
    setLeaves(res.data);
  } catch (err) {
    console.error('Error fetching leaves:', err);
  }
}, [token]);


  useEffect(() => {
    fetchLeaves();
  }, [fetchLeaves]);

  // ✅ Apply for leave
  const handleApply = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/leaves', form, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setForm({ start_date: '', end_date: '', reason: '' });
      setMessage('Leave applied successfully');
      setError('');
      fetchLeaves();
    } catch (err) {
      setError(err.response?.data?.message || 'Leave apply failed');
      setMessage('');
    }
  };

  // ✅ Cancel leave
  const handleCancel = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/leaves/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setMessage('Leave cancelled successfully');
      setError('');
      fetchLeaves();
    } catch (err) {
      setError(err.response?.data?.message || 'Cancel failed');
      setMessage('');
    }
  };

  // ✅ Filtered leaves
  const filteredLeaves = leaves.filter((leave) => {
    const leaveMonth = new Date(leave.start_date).toISOString().slice(0, 7);
    const matchMonth = !filterMonth || leaveMonth === filterMonth;
    const matchStatus = !filterStatus || leave.status === filterStatus;
    return matchMonth && matchStatus;
  });

  // ✅ Total approved or pending leaves for the year
  const totalLeavesThisYear = leaves.filter(
    (l) => ['approved', 'pending'].includes(l.status) &&
      new Date(l.start_date).getFullYear() === new Date().getFullYear()
  ).length;

  return (
    <div className="leave-section">
      <h3>Leave Management</h3>

      <form onSubmit={handleApply} className="leave-form">
       <div className="form-row">
        <label>Start Date:</label>
        <input
          type="date"
          value={form.start_date}
          onChange={(e) => setForm({ ...form, start_date: e.target.value })}
          required
        />
       </div>
         <div className="form-row">
        <label>End Date:</label>
        <input
          type="date"
          value={form.end_date}
          onChange={(e) => setForm({ ...form, end_date: e.target.value })}
          required
        />
        </div>
  <div className="form-row">
        <label>Reason:</label>
        <input
          type="text"
          value={form.reason}
          onChange={(e) => setForm({ ...form, reason: e.target.value })}
          required
        />
     </div>
        <button type="submit">Apply for Leave</button>
      </form>

      <div className="filters">
        <label>Filter Month:</label>
        <input
          type="month"
          value={filterMonth}
          onChange={(e) => setFilterMonth(e.target.value)}
        />

        <label>Status:</label>
        <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
          <option value="">All</option>
          <option value="pending">Pending</option>
          <option value="approved">Approved</option>
          <option value="rejected">Rejected</option>
        </select>
      </div>

      <p><strong>Total Leaves This Year:</strong> {totalLeavesThisYear}/20</p>

      {message && <p className="success">{message}</p>}
      {error && <p className="error">{error}</p>}

      {window.innerWidth >= 768 ? (
  // 👉 Desktop Table View
  <table className="leave-table">
    <thead>
      <tr>
        <th>Start</th>
        <th>End</th>
        <th>Reason</th>
        <th>Status</th>
        <th>Applied On</th>
        <th>Cancel</th>
      </tr>
    </thead>
    <tbody>
      {filteredLeaves.map((leave) => (
        <tr key={leave.id}>
          <td>{new Date(leave.start_date).toLocaleDateString()}</td>
          <td>{new Date(leave.end_date).toLocaleDateString()}</td>
          <td>{leave.reason}</td>
          <td>{leave.status}</td>
          <td>{new Date(leave.created_at).toLocaleDateString()}</td>
          <td>
            {leave.status === 'pending' && (
              <button onClick={() => handleCancel(leave.id)} className="cancel-button">Cancel</button>
            )}
          </td>
        </tr>
      ))}
    </tbody>
  </table>
) : (
  // 👉 Mobile Card View
  <div className="leave-cards">
    {filteredLeaves.map((leave) => (
      <div key={leave.id} className="leave-card">
        <p><strong>Start:</strong> {new Date(leave.start_date).toLocaleDateString()}</p>
        <p><strong>End:</strong> {new Date(leave.end_date).toLocaleDateString()}</p>
        <p><strong>Reason:</strong> {leave.reason}</p>
        <p><strong>Status:</strong> {leave.status}</p>
        <p><strong>Applied On:</strong> {new Date(leave.created_at).toLocaleDateString()}</p>
        {leave.status === 'pending' && (
          <button onClick={() => handleCancel(leave.id)} className="cancel-button">Cancel</button>
        )}
      </div>
    ))}
  </div>
)}

    </div>
  );
};

export default LeaveSection;
