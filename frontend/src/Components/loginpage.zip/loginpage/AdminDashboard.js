import { useEffect, useState, useCallback } from 'react';
import axios from 'axios';
import './AdminDashboard.css';
import { useNavigate } from 'react-router-dom';
import LeaveManagementSection from './LeaveManagementSection';
import TaskOverviewSection from './TaskOverviewSection';
import AnalyticsSection from './AnalyticsSection';
import EmployeeProfileViewer from './EmployeeProfileViewer';
import AdminSettingsSection from './AdminSettingsSection';
import AdminCorrectionPanel from './AdminCorrectionPanel';

const AdminDashboard = () => {
  const [records, setRecords] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [search, setSearch] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [error, setError] = useState('');
  const [employees, setEmployees] = useState([]);
  const [newEmployee, setNewEmployee] = useState({
    name: '',
    employee_id: '',
    email: '',
    password: '',
    phone: '',
    position: '',
    role: 'employee'
  });
  const [showEmployees, setShowEmployees] = useState(false);

  const token = localStorage.getItem('token');
  const navigate = useNavigate();

  const fetchRecords = useCallback(async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/attendance/attendance-records', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setRecords(res.data);
      setFiltered(res.data);
      setError('');
    } catch (err) {
      console.error(err);
      setError('Failed to fetch attendance records.');
    }
  }, [token]);

  const fetchEmployees = useCallback(async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/employees', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setEmployees(res.data);
    } catch (err) {
      console.error(err);
      setError('Failed to fetch employees.');
    }
  }, [token]);

  useEffect(() => {
    if (!token) navigate('/login');
    else fetchRecords();
  }, [token, navigate, fetchRecords]);

  useEffect(() => {
    let result = records;
    if (search) {
      result = result.filter((record) =>
        record.employee_name?.toLowerCase().includes(search.toLowerCase())
      );
    }
    if (selectedDate) {
      result = result.filter((record) => record.date === selectedDate);
    }
    setFiltered(result);
  }, [search, selectedDate, records]);

  const handleExportCSV = () => {
    const csvRows = [
      ['ID', 'Name', 'IP', 'Date', 'Punch In', 'Punch Out'],
      ...filtered.map((r) => [
        r.id,
        r.employee_name,
        r.ip,
        r.date,
        r.punch_in_time ? new Date(r.punch_in_time).toLocaleTimeString() : '',
        r.punch_out_time ? new Date(r.punch_out_time).toLocaleTimeString() : ''
      ])
    ];
    const blob = new Blob([csvRows.map((e) => e.join(',')).join('\n')], {
      type: 'text/csv'
    });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'attendance_records.csv';
    a.click();
  };

  const handleAddEmployee = async () => {
    const { name, employee_id, email, password } = newEmployee;
    if (!name || !employee_id || !email || !password) {
      setError('All fields are required.');
      return;
    }

    try {
      await axios.post('http://localhost:5000/api/employees', newEmployee, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setNewEmployee({
        name: '',
        employee_id: '',
        email: '',
        password: '',
        phone: '',
        position: '',
        role: 'employee'
      });
      fetchEmployees();
    } catch (err) {
      console.error(err);
      setError('Failed to add employee.');
    }
  };

  const handleDeleteEmployee = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/employees/${id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      fetchEmployees();
    } catch (err) {
      console.error(err);
      setError('Failed to delete employee.');
    }
  };

  const handleLogout = () => {
    localStorage.clear();
    navigate('/login');
  };

  const toggleEmployees = () => {
    if (!showEmployees) fetchEmployees();
    setShowEmployees(!showEmployees);
  };

  const updateLeaveQuota = async (id, quota) => {
    try {
      await axios.put(`http://localhost:5000/api/employees/${id}/leave-quota`,
        { leave_quota: quota },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert('Leave quota updated');
    } catch (err) {
      console.error('Failed to update leave quota:', err);
      alert('Failed to update leave quota');
    }
  };

  // ✅ Secure image fetch function
  const handleViewPhoto = async (id) => {
    try {
      const res = await fetch(`http://localhost:5000/api/attendance/photo/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      if (!res.ok) throw new Error('Failed to fetch photo');
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      window.open(url, '_blank');
    } catch (err) {
      console.error('Error opening photo:', err);
      alert('Unable to view photo');
    }
  };

  return (
    <div className="admin-dashboard">
      <div className="dashboard-header">
        <h2>Attendance Records</h2>
        <button onClick={handleLogout}>Logout</button>
      </div>

      <div className="filter-bar">
        <input type="text" placeholder="Search by name" value={search} onChange={(e) => setSearch(e.target.value)} />
        <input type="date" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} />
        <button onClick={handleExportCSV}>Export CSV</button>
      </div>

      {error && <p className="error-msg">{error}</p>}

      <h3>Employees</h3>
      <button onClick={toggleEmployees} className="toggle-btn">
        {showEmployees ? 'Hide Employees' : 'Show Employees'}
      </button>

      {showEmployees && (
        <>
          <div className="employee-form">
            <input placeholder="Name" value={newEmployee.name} onChange={(e) => setNewEmployee({ ...newEmployee, name: e.target.value })} />
            <input placeholder="Employee ID" value={newEmployee.employee_id} onChange={(e) => setNewEmployee({ ...newEmployee, employee_id: e.target.value })} />
            <input placeholder="Email" value={newEmployee.email} onChange={(e) => setNewEmployee({ ...newEmployee, email: e.target.value })} />
            <input placeholder="Phone" value={newEmployee.phone} onChange={(e) => setNewEmployee({ ...newEmployee, phone: e.target.value })} />
            <input placeholder="Password" type="password" value={newEmployee.password} onChange={(e) => setNewEmployee({ ...newEmployee, password: e.target.value })} />
            <input placeholder="Position" value={newEmployee.position} onChange={(e) => setNewEmployee({ ...newEmployee, position: e.target.value })} />
            <select value={newEmployee.role} onChange={(e) => setNewEmployee({ ...newEmployee, role: e.target.value })}>
              <option value="employee">Employee</option>
              <option value="admin">Admin</option>
            </select>
            <button onClick={handleAddEmployee}>Add Employee</button>
          </div>

          <ul className="employee-list">
            {employees.map(emp => (
              <li key={emp.id}>
                <strong>{emp.name}</strong> ({emp.email})<br />
                Position: {emp.position || 'N/A'} | Role: {emp.role}<br />
                Leave Quota:
                <input
                  type="number"
                  value={emp.leave_quota || 0}
                  onChange={(e) => {
                    const updatedQuota = parseInt(e.target.value, 10);
                    setEmployees(prev =>
                      prev.map(u =>
                        u.id === emp.id ? { ...u, leave_quota: updatedQuota } : u
                      )
                    );
                  }}
                  style={{ width: '60px', margin: '0 10px' }}
                />
                <button onClick={() => updateLeaveQuota(emp.id, emp.leave_quota)}>Save</button>
                <button onClick={() => handleDeleteEmployee(emp.id)}>Delete</button>
              </li>
            ))}
          </ul>
        </>
      )}

      <h3>Attendance</h3>
      {filtered.length === 0 ? (
        <p>No records found.</p>
      ) : (
        <div className="responsive-table-wrapper">
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>IP</th>
                <th>Date</th>
                <th>Punch In</th>
                <th>Punch Out</th>
                <th>Selfie</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((record) => (
                <tr key={record.id}>
                  <td data-label="ID">{record.id}</td>
                  <td data-label="Name">{record.employee_name}</td>
                  <td data-label="IP">{record.ip}</td>
                  <td data-label="Date">{record.date}</td>
                  <td data-label="Punch In">{record.punch_in_time ? new Date(record.punch_in_time).toLocaleTimeString() : '-'}</td>
                  <td data-label="Punch Out">{record.punch_out_time ? new Date(record.punch_out_time).toLocaleTimeString() : '-'}</td>
                  <td data-label="Selfie">
                    {record.photo_path ? (
                      <button onClick={() => handleViewPhoto(record.id)}>View</button>
                    ) : (
                      'No Image'
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <EmployeeProfileViewer />
      <AdminSettingsSection />
      <AdminCorrectionPanel token={token} />
      <LeaveManagementSection />
      <TaskOverviewSection />
      <AnalyticsSection />
    </div>
  );
};

export default AdminDashboard;
