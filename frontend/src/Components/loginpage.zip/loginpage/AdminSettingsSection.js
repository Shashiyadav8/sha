// components/AdminSettingsSection.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './AdminSettingsSection.css';

const AdminSettingsSection = () => {
  const [allowedIps, setAllowedIps] = useState('');
  const [allowedDevices, setAllowedDevices] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const res = await axios.get('http://localhost:5000/api/admin/settings', {
          headers: { Authorization: `Bearer ${token}` }
        });
        setAllowedIps(res.data.allowed_ips || '');
        setAllowedDevices(res.data.allowed_devices || '');
        setStartTime(res.data.working_hours_start || '');
        setEndTime(res.data.working_hours_end || '');
      } catch (err) {
        console.error('Error fetching admin settings:', err);
      }
    };

    fetchSettings();
  }, [token]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put('http://localhost:5000/api/admin/settings', {
        allowed_ips: allowedIps,
        allowed_devices: allowedDevices,
        working_start: startTime,
        working_end: endTime
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      alert('Settings updated successfully');
    } catch (err) {
      console.error('Error updating settings:', err);
      alert('Failed to update settings');
    }
  };

  return (
    <div className="admin-settings-section">
      <h3>⚙️ Admin Settings</h3>
      <form onSubmit={handleSubmit} className="settings-form">
        <label>Allowed WiFi IPs (comma-separated):</label>
        <input
          type="text"
          value={allowedIps}
          onChange={(e) => setAllowedIps(e.target.value)}
          placeholder="e.g. 192.168.1.1,192.168.0.105"
        />

        <label>Allowed Device IPs (comma-separated):</label>
        <input
          type="text"
          value={allowedDevices}
          onChange={(e) => setAllowedDevices(e.target.value)}
          placeholder="e.g. 192.168.1.100,127.0.0.1"
        />

        <label>Working Start Time:</label>
        <input
          type="time"
          value={startTime}
          onChange={(e) => setStartTime(e.target.value)}
        />

        <label>Working End Time:</label>
        <input
          type="time"
          value={endTime}
          onChange={(e) => setEndTime(e.target.value)}
        />

        <button type="submit">Update Settings</button>
      </form>
    </div>
  );
};

export default AdminSettingsSection;
